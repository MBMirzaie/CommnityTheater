/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package theater;

import java.io.*;
import java.text.*;
import java.util.*;

/**
 *
 * @author Marcus Mirzaie <marcus.mirzaie@mavs.uta.edu>
 * @version 1                   
 * @since   3/15/2014
 */
public class Theater extends Account
{
    
    private String theaterName;             // The name of your theater
    private double rentalCost;              // If the theater is rented, the monthly cost to rent
    private List<Play> plays;               // The play that is showing
    private int boxSeats;                   // How many box seats in the theater
    private int regSeats;                   // How many regular seats in the theater
    private double yearlyOperatingBudget;   // Yearly operating budget
    private List<Show> shows;               // The shows on the schedule
    private List<Customer> attendees;       // List of paying customers
    private Employee[] credits;             // List of employees
    private int currentMenu;                // Which menu to display options for
    private List<RentalItem> rentItems;      // Items rented for shows


    /**
     * 
     * @param theaterName set the theater name
     * @param rentalCost set the rental cost (include utilities)
     */
    public Theater(String theaterName, double rentalCost)
    {
        this.theaterName = theaterName;
        this.rentalCost = rentalCost;
        this.plays = new ArrayList();
        this.boxSeats = 0;
        this.regSeats = 0;
        this.yearlyOperatingBudget = 0;
        this.shows = new ArrayList();
        this.attendees = new ArrayList();
        this.credits = new Employee[1000];
        this.currentMenu = 0;
        this.rentItems = new ArrayList();
    }
    
    /**
     * @return the theater name
     */
    public String getTheaterName()
    {
        return theaterName;
    }

    /**
     * @param theaterName set the theater name
     */
    public void setTheaterName(String theaterName)
    {
        this.theaterName = theaterName;
    }

    /**
     * @return the cost to rent the theater (includes utilities)
     */
    public double getRentalCost()
    {
        return rentalCost;
    }

    /**
     * @param rentalCost the cost to rent the theater (include utilities)
     */
    public void setRentalCost(double rentalCost)
    {
        this.rentalCost = rentalCost;
    }

    /**
     * @return what plays will be showing
     */
    public List<Play> getShowingPlay()
    {
        return plays;
    }

    /**
     * @param plays set what play will be showing
     */
    public void setPlays(List<Play> plays)
    {
        this.plays = plays;
    }

    /**
     * @return the paying customers array
     */
    public List<Customer> getAttendees()
    {
        return attendees;
    }

    /**
     * @param attendees set the paying customers away
     */
    public void setAttendees(List<Customer> attendees)
    {
        this.attendees = attendees;
    }

    /**
     * @return the list of employees
     */
    public Employee[] getCredits()
    {
        return credits;
    }

    /**
     * @param credits set list of employees
     */
    public void setCredits(Employee[] credits)
    {
        this.credits = credits;
    }
    
    // Information gathering functions
    
    public void getTheaterInformation()
    {
        String tmp = new String();
        BufferedReader inPut;
        inPut = new BufferedReader(new InputStreamReader(System.in));

        System.out.printf("How many box seats does your theater have?  ");
        try
        {
            tmp = inPut.readLine();
        }
        catch(IOException ioe)
        {
            System.out.println("IO error trying to read line.");
            System.exit(1);
        }
        this.setBoxSeats(Integer.parseInt(tmp));
        System.out.printf("How many regular seats does your theater have?  ");
        try
        {
            tmp = inPut.readLine();
        }
        catch(IOException ioe)
        {
            System.out.println("IO error trying to read line.");
            System.exit(1);
        }
        this.setRegSeats(Integer.parseInt(tmp));
        System.out.printf("How much is the theater's yearly operating budget?  ");
        try
        {
            tmp = inPut.readLine();
        }
        catch(IOException ioe)
        {
            System.out.println("IO error trying to read line.");
            System.exit(1);
        }
        this.setYearlyOperatingBudget(Double.parseDouble(tmp));
    }
    public void addPlay()
    {
        String name;
        String author;
        int yearPublished;
        boolean WorldPremier;
        double playRental;
        
        System.out.printf("Please enter the play name:  ");
        name = this.getString();
        System.out.printf("Please enter the play author:  ");
        author = this.getString();
        System.out.printf("Please enter the year the play was published (yyyy):  ");
        yearPublished = this.getInt();
        System.out.printf("Please enter the if this the play's world premier(y/n):  ");
        WorldPremier = this.getString().startsWith("y");
        System.out.printf("Please enter the cost to rent the play (####.##):  ");
        playRental = this.getDouble();
        this.plays.add(new Play(name, author, yearPublished, WorldPremier, playRental));
        this.setCurrentMenu(2);
    }
    
    // Menus
    public void printMenu(int myMenu)
    {
        this.setCurrentMenu(myMenu);
        this.printMenu();
    }
    public boolean printMenu()
    {
        switch(currentMenu)
        {
            case 0: 
                this.mainMenu();
                break;
            case 1:
                this.empMenu();
                break;
            case 2:
                this.addPSIMenu();
                break;
            case 3:
                this.reserveMenu();
                break;
            case 4:
                this.acctMenu();
                break;
            case 5:
                return false;               
            case 6:     // empMenu 1 
                this.hireActor();
                break;
            case 7:     // empMenu 2
                this.hireDirector();
                break;
            case 8:     // empMenu 3
                this.fireEmployee();
                break;
            case 9:     // empMenu 4
                this.setCurrentMenu(0);
                break;
            case 10:    // psiMenu 1
                this.addPlay();
                break;
            case 11:    // psiMenu 2
                this.addShow();
                break;
            case 12:    // psiMenu 3
                this.addItem();
                break;
            case 13:    // psiMenu 4
                this.setCurrentMenu(0);
                break;
            case 14:    // reserveMenu 1
                this.addCustomer();
                break;
            case 15:    // reserveMenu 2
                this.reserveSeat();
                break;
            case 16:    // reserveMenu 3
                this.setCurrentMenu(0);
                break;
            default:
                this.setCurrentMenu(0);
        }
        return true;
    }
    public void mainMenu()
    {
        //Add Play/Show/Item
        //Sell ticket -> Add Customer/Sell Seat
        //Accounting -> Reconcile(Date)
        //Exit
        System.out.println("MAIN: Please choose from the follwoing options:");
        System.out.println("  1) Manage Employees");
        System.out.println("  2) Add Play/Show/Item");
        System.out.println("  3) Customers/Reservations");
        System.out.println("  4) Accounting");
        System.out.println("  5) Exit");
        this.setCurrentMenu(this.getInt());
    }
    public void empMenu()
    {
        System.out.println("Please choose from one of the following options:");
        System.out.println("  1) Hire an Actor");
        System.out.println("  2) Hire a Director");
        System.out.println("  3) Fire an Employee");
        System.out.println("  4) Main Menu");
        int tmp1 = this.getInt();
        this.setCurrentMenu((tmp1 == 0)?1:tmp1+5);
    }
    public void addPSIMenu()
    {
        System.out.println("Please choose from one of the following options:");
        System.out.println("  1) Add a Play");
        System.out.println("  2) Add a Show");
        System.out.println("  3) Add a Rental Item");
        System.out.println("  4) Main Menu");
        int tmp1 = this.getInt();
        this.setCurrentMenu((tmp1 == 0)?1:tmp1+9);
    }
    public void addItem()
    {
        String tmp; double tmp2;
        System.out.println("Please enter the name of the item to add.");
        tmp = this.getString();
        System.out.println("Please enter the cost per show to rent this item.");
        tmp2 = this.getDouble();
        this.rentItems.add(new RentalItem(tmp,tmp2));
        this.setCurrentMenu(2);
    }
    public void reserveMenu()
    {
        System.out.println("Please choose from one of the following options:");
        System.out.println("  1) Add Customer");
        System.out.println("  2) Make Reservation");
        System.out.println("  3) Main Menu");
        int tmp1 = this.getInt();
        this.setCurrentMenu((tmp1 == 0)?1:tmp1+13);
    }
    public void acctMenu()
    {
       System.out.println("Not yet implemented.");
       this.setCurrentMenu(0);
    }
    public void hireActor()
    {
        if(this.plays.isEmpty())
        {
            System.out.println("Please enter a play before trying to hire an actor.");
            this.setCurrentMenu(1);
            return;
        }
        int placement = 0;
        for(int i=0;i<1000;i++)
        {
            if(this.credits[i] == null)
            {
                placement = i;
                break;
            }
        }
        String roleName, hiredWhichPlay, lastName, firstName, street, state, zip; 
        int shirtSize, pantSize, clothesGender;
        double payScalePerHour;
        boolean actorsEquity; Date dateOfBirth; Address address;
        System.out.printf("Please enter the Actor/Actress's first name:  ");
        firstName = this.getString();
        System.out.printf("Please enter the Actor/Actress's last name:  ");
        lastName = this.getString();
        System.out.printf("Please enter the Actor/Actress's date of birth (mm-dd-yyyy):  ");
        dateOfBirth = this.getDate();
        System.out.printf("Please enter the Actor/Actress's street address:  ");
        street = this.getString();
        System.out.printf("Please enter the Actor/Actress's state:  ");
        state = this.getString();
        System.out.printf("Please enter the Actor/Actress's zip code:  ");
        zip = this.getString();
        address = new Address(street, state, Integer.parseInt(zip));
        System.out.printf("Does this Actor/Actress's have actor's equity (y/n)?  ");
        actorsEquity = this.getString().startsWith("y");
        System.out.printf("Please enter the Actor/Actress's pay per hour:  ");
        payScalePerHour = Double.parseDouble(this.getString());
        System.out.printf("Please enter which play the Actor/Actress's was hired:  ");
        hiredWhichPlay = this.getString();
        System.out.printf("Please enter the Actor/Actress's role name:  ");
        roleName = this.getString();
        System.out.printf("Please enter the Actor/Actress's shirt size:  ");
        shirtSize = Integer.parseInt(this.getString());
        System.out.printf("Please enter the Actor/Actress's pant size:  ");
        pantSize = Integer.parseInt(this.getString());
        System.out.printf("Please enter the Actor/Actress's clothes gender (m/f):  ");
        clothesGender = ((this.getString().startsWith("m"))?0:1);
        this.credits[placement] = new Actor(roleName, shirtSize, pantSize, clothesGender, hiredWhichPlay, payScalePerHour, actorsEquity, lastName, firstName, dateOfBirth, address);
        this.setCurrentMenu(1);
    }
    public String getString()
    {
        String tmp = new String();
        BufferedReader inPut;
        inPut = new BufferedReader(new InputStreamReader(System.in));
        
        try
        {
            tmp = inPut.readLine();
        }
        catch(IOException ioe)
        {
            System.out.println("IO error trying to read line.");
            System.exit(1);
        }
        
        return tmp;
    }
    public Date getDate()
    {
        Date tmpDate = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("dd-MM-yyyy"); 

        try
        {
            tmpDate = ft.parse(this.getString());
        }
        catch(ParseException e)
        {
            System.out.println("Bad date entered.");
            System.exit(1);
        }        
        return tmpDate;
    }
    public int getInt()
    {
        int tmp2 = 0;
        try{tmp2 = Integer.parseInt(this.getString());}
        catch(NumberFormatException e){ System.out.println("Invalid choice.");}
        return tmp2;
    }
    public double getDouble()
    {
        double tmp2 = 0;
        try{tmp2 = Double.parseDouble(this.getString());}
        catch(NumberFormatException e){ System.out.println("Invalid choice.");}
        return tmp2;
    }
    public void hireDirector()
    {
        System.out.println("Directors no implemented yet.");
        this.setCurrentMenu(1);
    }
    public void fireEmployee()
    {
        if(credits[0] == null)
        {
            System.out.println("No employees to fire.");
            this.setCurrentMenu(1);
            return;
        }
        System.out.printf("Please confirm which actor/actress to fire:\n");
        for(Employee c:credits)
        {
            System.out.printf("%s %s(y/n):  ",c.getFirstName(),c.getLastName());
            if(this.getString().startsWith("y")) 
            {
                c.setTerminated(true);
                break;
            }   
        }
        this.setCurrentMenu(1);
    }
    public void addCustomer()
    {
        String lastName, firstName, street, state; 
        int zip; Date dateOfBirth; Address address;
        System.out.printf("Please enter the customer's first name:  ");
        firstName = this.getString();
        System.out.printf("Please enter the customer's last name:  ");
        lastName = this.getString();
        System.out.printf("Please enter the customer's date of birth (mm-dd-yyyy):  ");
        dateOfBirth = this.getDate();
        System.out.printf("Please enter the customer's street address:  ");
        street = this.getString();
        System.out.printf("Please enter the customer's state:  ");
        state = this.getString();
        System.out.printf("Please enter the customer's zip code:  ");
        zip = this.getInt();
        address = new Address(street, state, zip);
        this.attendees.add(new Customer(lastName, firstName, dateOfBirth, address));
        this.setCurrentMenu(1);
    }
    public void reserveSeat()
    {
        int play = 0;
        int customer = 0;
        if(this.attendees.isEmpty())
        {
            System.out.println("Please add some customers before making reservations.");
            this.setCurrentMenu(2);
            return;
        }
        if(this.plays.isEmpty())
        {
            System.out.println("Please add at least one play before making reservations.");
            this.setCurrentMenu(2);
            return;
        }
        if(this.shows.isEmpty())
        {
            System.out.println("Please add some shows before making reservations.");
            this.setCurrentMenu(2);
            return;
        }
        // Get who
        System.out.printf("Please confirm which attendee is reserving:\n");
        for(Customer c:attendees)
        {
            System.out.printf("%s %s(y/n):  ",c.getFirstName(),c.getLastName());
            if(this.getString().startsWith("y")) 
            {
                customer = c.getpID();
                break;
            }
        }
        if(customer == 0) 
        {
            this.setCurrentMenu(0);
            return;
        }
        // Get which play
        System.out.printf("Please confirm which Play:\n");
        for(Play p:plays)
        {
            System.out.printf("%s (y/n):  ",p.getName());
            if(this.getString().startsWith("y")) 
            {
                play = p.getpID();
                break;
            }
        }
        if(play == 0) 
        {
            this.setCurrentMenu(0);
            return;
        }

        // Get which show seat
        System.out.printf("Please choose a showing:\n");
        for(Show s:shows)
        {
            if(s.getWhichPlay() == play) 
            {
                System.out.printf("%s %s (y/n):  ",s.getShowDate(),(s.isMatinee())?"Matinee":"Night");
                if(this.getString().startsWith("y")) 
                {
                    // Box or regular
                    System.out.printf("Would you like a box seat (y/n)?  ");
                    if(this.getString().startsWith("y")) 
                    {
                        s.reserveBoxSeat(customer);
                        this.setCurrentMenu(0);
                    }
                    else
                    {
                        s.reserveRegSeat(customer);
                        this.setCurrentMenu(0);
                    }
                }
            }
        }
        this.setCurrentMenu(0);
    }
    public boolean rentItem()
    {
        // Get item info
        // return if added
        return false;
    }

    /**
     * @return the yearly operating budget
     */
    public double getYearlyOperatingBudget()
    {
        return yearlyOperatingBudget;
    }

    /**
     * @param yearlyOperatingBudget set the yearly operating budget
     */
    public void setYearlyOperatingBudget(double yearlyOperatingBudget)
    {
        this.yearlyOperatingBudget = yearlyOperatingBudget;
    }

    /**
     * @return the shows
     */
    public List<Show> getShows()
    {
        return shows;
    }

    /**
     * @param shows the shows to set
     */
    public void setShows(List<Show> shows)
    {
        this.shows = shows;
    }

    /**
     * @return the number of box seats in the theater
     */
    public int getBoxSeats()
    {
        return boxSeats;
    }

    /**
     * @param boxSeats set the number of box seats in the theater
     */
    public void setBoxSeats(int boxSeats)
    {
        this.boxSeats = boxSeats;
    }

    /**
     * @return the number of regular seats in the theater
     */
    public int getRegSeats()
    {
        return regSeats;
    }

    /**
     * @param regSeats set the number of regular seats in the theater
     */
    public void setRegSeats(int regSeats)
    {
        this.regSeats = regSeats;
    }
    
    public void addShow()
    {
        int play = 0;
        Date tmpDate;
        boolean tmpMatinee;

       // Get which play
        System.out.printf("Please confirm which Play:\n");
        for(Play p:plays)
        {
            System.out.printf("%s (y/n):  ",p.getName());
            if(this.getString().startsWith("y")) 
            {
                play = p.getpID();
                break;
            }
        }
        if(play == 0) 
        {
            System.out.println("Failed to add show.  No play selected.");
            this.setCurrentMenu(2);
            return;
        }

        
        System.out.printf("Please enter date of the show (mm-dd-yyyy):  ");
        tmpDate = this.getDate();
       
        System.out.printf("Is this a matinee(y/n):  ");
        tmpMatinee = this.getString().startsWith("y");        
        this.shows.add(new Show(tmpDate,this.getBoxSeats(),this.getRegSeats(),play,tmpMatinee));
        this.setCurrentMenu(2);
    }

    /**
     * @return the currentMenu
     */
    public int getCurrentMenu()
    {
        return currentMenu;
    }

    /**
     * @param currentMenu the currentMenu to set
     */
    public void setCurrentMenu(int currentMenu)
    {
        this.currentMenu = currentMenu;
    }
}
