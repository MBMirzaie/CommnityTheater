/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package theater;

/**
 *
 * @author Marcus Mirzaie <marcus.mirzaie@mavs.uta.edu>
 * @version 1                   
 * @since   3/20/2014
 */
public class Account 
{
    private double balance;     // Current contribution(-)/pay(+)
    private double need;        // Required adjustment
    
    /**
     * Default constructor
     * <P>
     * Default constructor with no arguments to give
     * members and methods to child classes.
     * <P>
     */
    public Account()
    {
    }

    /**
     * @return the Current contribution(-)/pay(+)
     */
    public double getBalance()
    {
        return balance;
    }

    /**
     * @param balance set the Current contribution(-)/pay(+)
     */
    public void setBalance(double balance)
    {
        this.balance = balance;
    }

    /**
     * @return the Required adjustment
     */
    public double getNeed()
    {
        return need;
    }

    /**
     * @param need set the Required adjustment
     */
    public void setNeed(double need)
    {
        this.need = need;
    }
    
    /**
     * 
     * @return the amount adjusted
     */
    public double payBalance()
    {
        double tmp = this.getNeed();
        this.setBalance(this.getBalance()+this.getNeed());
        this.setNeed(0);
        return tmp;
    }
    
    /**
     * @param amount set the Required adjustment
     */
    public void payAmount(double amount)
    {
        this.setBalance(this.getBalance()+amount);
        this.setNeed(this.getNeed()+amount);
    }
    
}
