package theater;

import java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author  Marcus Mirzaie <marcus.mirzaie@mavs.uta.edu>
 * @version 1                   
 * @since   3/15/2014
 */
public class Employee extends Person
{
	private String hiredWhichPlay;		// Which play was this theater person hired on?
        private double payScalePerHour;            // Hourly wage
        private boolean actorsEquity;           // Actor's Equity..  WTF?
        private boolean terminated;             // Have they been fired?
//        private Date terminated = null;         // Have they been fired? (null if no)
        
    /**
     * @param firstName Set the First name of Person
     * @param dateOfBirth Set the Date of Birth of Person
     * @param address Set the Address of Person
     * @param lastName Set the Last name of Person
     * @param hiredWhichPlay Set which play they were hired
     * @param payScalePerHour Set their hourly wage
     * @param actorsEquity Set the Actor's Equity
     */        
    public Employee(String hiredWhichPlay, double payScalePerHour, boolean actorsEquity, String lastName, String firstName, Date dateOfBirth, Address address) {
        super(lastName, firstName, dateOfBirth, address);
        this.hiredWhichPlay = hiredWhichPlay;
        this.payScalePerHour = payScalePerHour;
        this.actorsEquity = actorsEquity;
    }

    /**
     * @return Which play they were hired
     */
    public String getHiredWhichPlay() {
        return hiredWhichPlay;
    }

    /**
     * @param hiredWhichPlay Set which play they were hired
     */
    public void setHiredWhichPlay(String hiredWhichPlay) {
        this.hiredWhichPlay = hiredWhichPlay;
    }

    /**
     * @return Their hourly wage
     */
    public double getPayScalePerHour() {
        return payScalePerHour;
    }

    /**
     * @param payScalePerHour Set their hourly wage
     */
    public void setPayScalePerHour(double payScalePerHour) {
        this.payScalePerHour = payScalePerHour;
    }

    /**
     * @return the Actor's Equity
     */
    public boolean isActorsEquity() {
        return actorsEquity;
    }

    /**
     * @param actorsEquity Set the Actor's Equity
     */
    public void setActorsEquity(boolean actorsEquity) {
        this.actorsEquity = actorsEquity;
    }


    @Override
    public String toString() {
        return super.toString() + "|" + hiredWhichPlay + "|" + payScalePerHour + "|" + actorsEquity + "|" + isTerminated();
                
    }

//    /**
//     * @return whether or not they have been fired
//     */
//    public Date isTerminated()
//    {
//        return terminated;
//    }
//
//    /**
//     * @param terminated Set whether or not they have been fired
//     */
//    public void setTerminated(Date terminated)
//    {
//        this.terminated = terminated;
//    }

    /**
     * @return the terminated
     */
    public boolean isTerminated()
    {
        return terminated;
    }

    /**
     * @param terminated the terminated to set
     */
    public void setTerminated(boolean terminated)
    {
        this.terminated = terminated;
    }

}
