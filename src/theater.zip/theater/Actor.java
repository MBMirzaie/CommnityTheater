/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package theater;

import java.util.Date;

/**
 *
 * @author Marcus Mirzaie <marcus.mirzaie@mavs.uta.edu>
 */
public class Actor extends Employee
{
	private String roleName;		// Role name the actor plays
	private int shirtSize;			// Their shirt size
	private int pantSize;			// Their pant size
	private int clothesGender; 		// 1 = female, 0= male;

    /**
     * @param firstName Set the First name of Person
     * @param dateOfBirth Set the Date of Birth of Person
     * @param address Set the Address of Person
     * @param lastName Set the Last name of Person
     * @param hiredWhichPlay Set which play they were hired
     * @param payScalePerHour Set their hourly wage
     * @param actorsEquity Set the Actor's Equity
     * @param roleName Set the role the Actor/Actress plays
     * @param shirtSize Set the shirt size the Actor/Actress wears
     * @param pantSize Set the pant size the Actor/Actress wears
     * @param clothesGender Set the clothes gender the Actor/Actress will be wearing - 0 for men, 1 for women
     */    
    public Actor(String roleName, int shirtSize, int pantSize, int clothesGender, String hiredWhichPlay, double payScalePerHour, boolean actorsEquity, String lastName, String firstName, Date dateOfBirth, Address address)
    {
        super(hiredWhichPlay, payScalePerHour, actorsEquity, lastName, firstName, dateOfBirth, address);
        this.roleName = roleName;
        this.shirtSize = shirtSize;
        this.pantSize = pantSize;
        this.clothesGender = clothesGender;
    }

        
    /**
     * @return the role the Actor/Actress plays
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * @param roleName Set the role the Actor/Actress plays
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * @return the shirt size the Actor/Actress wears
     */
    public int getShirtSize() {
        return shirtSize;
    }

    /**
     * @param shirtSize Set the shirt size the Actor/Actress wears
     */
    public void setShirtSize(int shirtSize) {
        this.shirtSize = shirtSize;
    }

    /**
     * @return the pant size the Actor/Actress wears
     */
    public int getPantSize() {
        return pantSize;
    }

    /**
     * @param pantSize Set the pant size the Actor/Actress wears
     */
    public void setPantSize(int pantSize) {
        this.pantSize = pantSize;
    }

    /**
     * @return the clothes gender the Actor/Actress will be wearing
     */
    public int getClothesGender() {
        return clothesGender;
    }

    /**
     * @param clothesGender Set the clothes gender the Actor/Actress will be wearing - 0 for men, 1 for women
     */
    public void setClothesGender(int clothesGender) {
        this.clothesGender = clothesGender;
    }

    @Override
    public String toString() {
        return "Actor|" + roleName + "|" + shirtSize + "|" + pantSize + "|" + ((clothesGender == 0)?"MENS":"WOMENS");
    }
           
}
